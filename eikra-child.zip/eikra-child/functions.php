<?php
add_filter('learn-press/enroll-course-button-text', function ($text){
$text = 'Matricular';
return $text;
});